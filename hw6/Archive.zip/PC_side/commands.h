#ifndef __COMMANDS_H__
#define __COMMANDS_H__

#define chCmd_LED_ON        "LED ON"
#define chCmd_LED_OFF       "LED OFF"
#define chCmd_BUTTON_STATUS "BUTTON:STATUS?"
#endif //CPL_COMMANDS_H
